/**
 * Host half of the dsh-shot bundle.
 *
 * The desktop shell registers no `setDisplayMediaRequestHandler`, so
 * `navigator.mediaDevices.getDisplayMedia()` is unavailable inside the app
 * window: the page cannot grab the screen on its own. This half owns that one
 * missing capability and publishes it as a same-origin GET route that the
 * Client module fetches. Cropping, previewing and handing the resulting PNG to
 * the composer all stay in the Client module.
 */
import { execFile } from 'node:child_process'
import { mkdtemp, readFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { promisify } from 'node:util'

const execFileAsync = promisify(execFile)

/** Route owned by this bundle; the Client half fetches exactly this path. */
const ROUTE_PATH = '/dsh-shot/capture'
const CAPTURE_TIMEOUT_MS = 25_000
const MAX_IMAGE_BYTES = 64 * 1024 * 1024

/**
 * PowerShell screen grab. It is passed as `-EncodedCommand` (UTF-16LE base64)
 * so that no quoting layer can mangle the script, and the destination path
 * arrives through the environment instead of being interpolated into the code.
 * `SetProcessDPIAware` keeps `CopyFromScreen` at native physical pixels, and
 * `VirtualScreen` covers every monitor rather than the primary one only.
 */
const WINDOWS_CAPTURE_SCRIPT = `
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public static class DshShotDpi { [DllImport("user32.dll")] public static extern bool SetProcessDPIAware(); }'
[void][DshShotDpi]::SetProcessDPIAware()
$bounds = [System.Windows.Forms.SystemInformation]::VirtualScreen
$bitmap = New-Object System.Drawing.Bitmap $bounds.Width, $bounds.Height
$graphics = [System.Drawing.Graphics]::FromImage($bitmap)
try {
  $graphics.CopyFromScreen($bounds.Left, $bounds.Top, 0, 0, $bitmap.Size)
} finally {
  $graphics.Dispose()
}
try {
  $bitmap.Save($env:DSH_SHOT_OUT, [System.Drawing.Imaging.ImageFormat]::Png)
} finally {
  $bitmap.Dispose()
}
`

export const name = 'dsh-shot'

/** One grab at a time: PowerShell would happily race itself on the same machine. */
let capturing = false

function sendJson(response, status, body) {
  const payload = Buffer.from(JSON.stringify(body), 'utf8')
  response.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': String(payload.byteLength),
    'cache-control': 'no-store',
  })
  response.end(payload)
}

async function runWindowsCapture(file) {
  const command = Buffer.from(WINDOWS_CAPTURE_SCRIPT, 'utf16le').toString('base64')
  await execFileAsync('powershell.exe', [
    '-NoProfile',
    '-NonInteractive',
    '-ExecutionPolicy',
    'Bypass',
    '-EncodedCommand',
    command,
  ], {
    env: { ...process.env, DSH_SHOT_OUT: file },
    windowsHide: true,
    timeout: CAPTURE_TIMEOUT_MS,
    maxBuffer: 1024 * 1024,
  })
}

async function runDarwinCapture(file) {
  await execFileAsync('/usr/sbin/screencapture', ['-x', '-t', 'png', file], {
    timeout: CAPTURE_TIMEOUT_MS,
  })
}

/**
 * Grab the whole virtual screen and return the encoded PNG.
 *
 * The temporary directory is removed on every path, including failures, so a
 * crashed grab never leaves a full-screen bitmap behind in the OS temp area.
 */
export async function captureScreen() {
  const directory = await mkdtemp(join(tmpdir(), 'dsh-shot-'))
  const file = join(directory, 'screen.png')
  try {
    if (process.platform === 'win32') await runWindowsCapture(file)
    else if (process.platform === 'darwin') await runDarwinCapture(file)
    else throw new Error(`screen capture is not implemented for platform "${process.platform}"`)
    const image = await readFile(file)
    if (image.byteLength < 1024) throw new Error('the screen capture produced no image data')
    if (image.byteLength > MAX_IMAGE_BYTES) throw new Error('the screen capture is larger than the transfer limit')
    return image
  } finally {
    await rm(directory, { recursive: true, force: true }).catch(() => {})
  }
}

async function handleCapture(request, response) {
  if (request.method !== 'GET' && request.method !== 'HEAD') {
    response.writeHead(405, { allow: 'GET' })
    response.end()
    return
  }
  if (capturing) {
    sendJson(response, 429, { error: 'a screen capture is already running' })
    return
  }
  capturing = true
  try {
    const image = await captureScreen()
    response.writeHead(200, {
      'content-type': 'image/png',
      'content-length': String(image.byteLength),
      'cache-control': 'no-store',
    })
    response.end(image)
  } catch (error) {
    sendJson(response, 500, { error: error instanceof Error ? error.message : String(error) })
  } finally {
    capturing = false
  }
}

export function apply(ctx) {
  ctx.inject(['webServer'], (hostCtx) => {
    hostCtx.effect(
      () => hostCtx.webServer.register({ kind: 'exact', path: ROUTE_PATH, handler: handleCapture }),
      'dsh-shot: screen capture route',
    )
  })
}
