# dsh-shot · 截图到对话

给 [DeepSeek Harness](https://github.com/deepseek-ai) 聊天输入框加一个「截图」按钮：框选桌面任意区域，裁剪结果直接作为图片附件进入当前会话的草稿（不会自动发送，你确认后再发）。

![输入框工具行里的截图按钮](docs/composer.png)

> 工具行左侧 `+`、权限按钮之后的那个取景框图标就是它。下面 8 倍放大：四角括号 + 虚线内框。

<img src="docs/button.png" alt="截图按钮放大" width="360">

## 功能

- **左键**：立即截取整屏 → 全屏选区浮层 → 拖拽框选
- **右键**：3 秒后自动截取（用来先切换到别的窗口，避免把 DSH 自己截进去）
- 浮层内：**拖拽**框选任意区域，**单击**=整屏，**Esc**=取消；底部按钮：`整屏` / `重新截取` / `延时 3 秒` / `取消` / `加入对话`
- 点「加入对话」后，裁剪出的 PNG 进入输入框附件栏，跟「+ 附件」加入的图片完全等价（可预览、可移除、可和文字一起发）
- 长边超过 2400px 时自动等比降采样，避免整屏 4K 截图把附件撑得过大
- 中文 / 英文界面文案跟随 DSH 当前语言
- 只截用户主动触发的那一次；截图在本机生成，不联网

## 为什么截屏必须由 Host 半部做

DSH 桌面端是 Electron。它的主进程**没有**注册 `desktopCapturer` 或 `setDisplayMediaRequestHandler`，所以页面里的 `navigator.mediaDevices.getDisplayMedia()` 拿不到任何屏幕流——纯前端插件无法截屏。

因此本插件切成两半：

| 半部 | 位置 | 职责 |
| --- | --- | --- |
| Host | `index.js` | 用 `ctx.inject(['webServer'])` 注册 `GET /dsh-shot/capture`，在 Host 进程里调用系统截屏工具抓整屏，返回 `image/png` |
| Client | `client.js` | 在输入框工具行放按钮、在 `shell.overlay` 放全屏选区浮层；选区用 canvas 裁剪成 PNG `File`，再交给会话草稿 |

Client 用同源 `fetch('/dsh-shot/capture', { credentials: 'same-origin' })` 取图。桌面端页面跑在 `dsh-app://` scheme 上，Electron 会把非静态资源路径转发给 Host 的 HTTP 服务并带上认证 cookie，所以这条路由在页面里可以直接用，插件不需要自带任何网关或鉴权。

## 安装

前提：已经装好 DeepSeek Harness（桌面端或 web 端均可，宿主需要有 `webServer` 服务，标准发行版都有）。**不需要** `npm install`，本插件零第三方依赖。

### 方式一：让 DSH 装（推荐）

把整个仓库目录放到磁盘任意位置，然后让 DSH Agent 执行它的插件安装动作，目标是**该目录的绝对路径**，例如：

```text
plugin_manager install_bundle(target="D:/plugins/dsh-shot")
```

安装成功后 DSH 会把它挂进当前 profile 的 `cordis.patch.yml`，并在 `node_modules/@local/dsh-shot` 下建立指向源目录的链接（junction / symlink），之后改源码即时生效（Client 半部靠 HMR 热重载，约 1 秒）。

### 方式二：手动安装

1. 把本目录放到任意位置（设为 `SRC`）。
2. 在当前 profile 的 `node_modules/@local/dsh-shot` 建一个指向 `SRC` 的链接（Windows：`mklink /J`；macOS/Linux：`ln -s`）。
   profile 目录一般是：
   - Windows：`%USERPROFILE%\.dsh\profiles\<profile>\`
   - macOS/Linux：`~/.dsh/profiles/<profile>/`
3. 在该 profile 的 `cordis.patch.yml` 里追加一行 insert（**只加这一行，别改别人的条目**）：

   ```yaml
   - insert:
       - id: dsh-shot
         name: '@local/dsh-shot'
   ```

4. 重启 DSH（或触发 profile 重载）。

装好后在聊天输入框工具行左侧应该能看到取景框图标。

## 用法

1. 点工具栏的取景框图标。浮层会盖住整个应用窗口，显示刚才截到的整屏图。
2. 拖出一个矩形（`整屏` 按钮可直接选满屏）；`重新截取` 再抓一次；`Esc` / `取消` 放弃。
3. 点 `加入对话`，图片作为附件进入草稿，浮层自动关闭。
4. 想截别的窗口？**右键**图标（或浮层里点 `延时 3 秒`），会有 3 秒时间把目标窗口切到前面。

## 平台支持

| 平台 | 截屏实现 | 状态 |
| --- | --- | --- |
| Windows | PowerShell + `System.Windows.Forms` / `System.Drawing` 的 `CopyFromScreen`（DPI aware，覆盖所有显示器的虚拟屏幕） | 已验证 |
| macOS | `/usr/sbin/screencapture -x -t png`（需在「系统设置 → 隐私与安全性 → 屏幕录制」里授权 DSH） | 代码已就绪，未在真机验证 |
| Linux | — | 未实现，路由会返回 `500` 与说明性错误信息 |

> 在 web 端使用时，截到的是**Host 所在机器**的屏幕，而不是你浏览器所在机器。

## 数据流向与隐私

1. Host 进程把整屏写入系统临时目录下的一个临时文件；
2. 读成 Buffer 后立刻删除该临时目录（`finally`，失败也会删）；
3. 通过同源路由把 PNG 字节交给页面，页面用 `URL.createObjectURL` 生成 blob；
4. 裁剪后的 `File` 进入会话草稿——**图片由前端以 objectURL 持有，只有你点发送时才会真正随消息上传**；
5. 全程不做任何外部网络请求，也不写日志文件。

同一时刻只允许一次截屏：并发请求会收到 `429 {"error":"a screen capture is already running"}`。

## 目录结构

```text
.
├─ index.js            # Host 半部：注册 /dsh-shot/capture，调用系统截屏
├─ client.js           # Client 半部：工具行按钮 + 全屏选区浮层 + 入草稿
├─ cordis.patch.yml    # bundle 安装补丁（insert 一行）
├─ package.json        # bundle manifest：dsh.bundle.patch / dsh.client
├─ icon.svg            # 插件图标（≤256 KiB）
├─ locale/{zh,en}.json # 插件市场里的标题与描述
├─ tests/smoke.mjs     # 无浏览器 smoke 测试
└─ .github/workflows/ci.yml
```

### 关键实现点

- Client 是**静态客户端模块**：`window.__ModuleLoader__.load({ id: '<包名>', factory(require) { ... } })`，`id` 必须与 `package.json` 的 `name` 完全一致。
- 按钮挂在 `conversation.input.left`（输入框工具行左侧、`replaceRisk: none` 的空位，不遮蔽任何出厂控件）。
- 浮层挂在 `shell.overlay`（框架级浮层，天然 click-through，条目自己接管指针事件）。
- 两个 slot 条目拿不到彼此的 props，所以用模块级 store（`subscribe` / `useSyncExternalStore` 风格）通信，`commit` 函数在 `apply()` 里赋给模块级变量。
- 入草稿用的是 DSH 官方同一套链路：

  ```js
  const conversation = ctx.get('conversation')
  const drafts = conversation.createDrafts(sessionId, [file])   // 同步；图片走前端 objectURL
  if (inputActions.addAttachments(drafts.map(d => d.id)) !== true) {
    conversation.releaseDraftAttachments(drafts)                 // 失败回滚，绝不留下孤儿草稿
  }
  ```

  这与官方 `+ 附件` 按钮内部路径（`createDrafts` → `shell.addFiles`）同构。
- 样式只用主题 token（`--dsw-alias-*`，全部带 fallback），不 import 任何 DSH Client 包，跟随明暗主题。

## 开发

```bash
node --check index.js && node --check client.js   # 语法检查（npm run check）
node tests/smoke.mjs                              # 逻辑级 smoke 测试（npm test）
```

`tests/smoke.mjs` 不需要浏览器：它用一个假的 `window.__ModuleLoader__`、带状态的最小 React、假的 cordis `ctx`（含 `slots` / `locale` / `get('conversation')`）和假的 canvas / Image / fetch 加载**真实的 `client.js`**，然后模拟「点按钮 → 抓图 → 选满屏 → 加入对话」，断言：

- 模块 id、两个 slot 注册、locale 字典注册；
- 左键与右键各触发一次抓取请求（`credentials: 'same-origin'`）；
- 浮层工具条恰好 5 个按钮、未选区时「加入对话」禁用；
- 裁剪参数（整屏 2560×1600 → 降采样 2400×1500）与 `drawImage` 调用；
- `createDrafts` 收到的 sessionId / `Blob` / `image/png` / 文件名格式，`addAttachments` 收到的草稿 id，以及失败回滚路径。

CI 在 Node 20 / 22 上跑这两条命令。

## 已知限制

- **会把 DSH 自己截进去**：Electron 主进程没有暴露隐藏/最小化窗口的 IPC，插件无法在抓图前把自己藏起来。请用右键的「延时 3 秒」先切到目标窗口。
- 选区坐标按图片显示框换算，多显示器（虚拟屏幕）截图同样适用，但只支持「矩形裁剪」，没有窗口吸附。
- 曾有过的验证边界：按钮在真实界面里通过截图确认过渲染；但**没有做自动化鼠标点击的端到端验证**（会抢占用户前台窗口、可能误点别的应用），所以浮层的交互只有逻辑级测试覆盖。若有点击后异常，欢迎提 issue。
- 插件未发布到 DSH 插件市场，只能本地安装（所以 `private: true`）。

## 改名后再发布

仓库里包名用的是 `@local/dsh-shot`。若你想换成自己的名字（例如 `@your-name/dsh-shot` 或 `dsh-shot`），要**同时**改这三处，否则 Client 模块加载不上：

1. `package.json` 的 `name`；
2. `client.js` 第一行 `window.__ModuleLoader__.load({ id: '<包名>', ... })` 里的 `id`；
3. `cordis.patch.yml` 里 `name: '@local/dsh-shot'`。

改完重装一次插件即可。

另外这些占位符记得替换：`package.json` 的 `repository.url` / `homepage` / `bugs.url` 里的 `YOUR-GITHUB-NAME`、`author` 字段、以及 `LICENSE` 的版权署名。

## License

[MIT](LICENSE)

---

## English

A DeepSeek Harness bundle that adds a **screenshot** button to the chat composer: drag-select any screen region, and the cropped PNG lands in the draft attachments of the current session.

- Left click = grab now; right click = grab in 3 seconds (so you can bring another window forward).
- The Electron shell exposes no `desktopCapturer` / display-media handler, so the page cannot capture the screen itself. This bundle therefore ships two halves: a Host half registering `GET /dsh-shot/capture` (PowerShell `CopyFromScreen` on Windows, `screencapture` on macOS) and a Client half that renders the button (`conversation.input.left`) and the selection overlay (`shell.overlay`).
- Insertion uses the same path as the built-in attachment button: `conversation.createDrafts()` → `inputActions.addAttachments()`, with `releaseDraftAttachments()` rollback on failure.
- Zero third-party dependencies; MIT licensed. Run `node tests/smoke.mjs` for the browser-free logic test.
