// Smoke test for ../client.js without a browser.
//
// Loads the real client module with a fake __ModuleLoader__, runs apply() to
// register the slots, presses the trigger, renders the crop surface with a fake
// layout, selects the whole frame, inserts it, and checks every hand-off on the
// way to the conversation draft. Run: node tests/smoke.mjs
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'

const SOURCE = fileURLToPath(new URL('../client.js', import.meta.url))
const code = readFileSync(SOURCE, 'utf8')
const fail = []
const check = (ok, message) => {
  if (!ok) fail.push(message)
}
const tick = () => new Promise((resolve) => setTimeout(resolve, 20))

/* --------------------------- fake module host --------------------------- */
let loaded = null
const fakeWindow = {
  __ModuleLoader__: {
    load(definition) {
      loaded = definition
    },
  },
  // Run delayed work immediately: the delay only matters for the real user.
  setTimeout: (fn) => {
    fn()
    return 0
  },
  addEventListener() {},
  removeEventListener() {},
}

/* ------------------------- tiny stateful React -------------------------- */
// Real React keeps hook state per component instance. The crop surface relies on
// that, so the harness keeps one fiber per component and renders it in a loop
// until no setter fired during the pass.
let fiber = null

const fakeReact = {
  createElement(type, props, ...children) {
    const element = { type, props: props === null || props === undefined ? {} : { ...props } }
    const flat = children.flat().filter((child) => child !== null && child !== undefined && child !== false)
    if (flat.length > 0) element.children = flat
    return element
  },
  useState(initial) {
    const index = fiber.index++
    if (!(index in fiber.hooks)) {
      fiber.hooks[index] = typeof initial === 'function' ? initial() : initial
    }
    const setter = (next) => {
      const current = fiber.hooks[index]
      fiber.hooks[index] = typeof next === 'function' ? next(current) : next
      fiber.dirty = true
    }
    return [fiber.hooks[index], setter]
  },
  useEffect() {},
  useRef(initial) {
    const index = fiber.index++
    if (!(index in fiber.hooks)) fiber.hooks[index] = { current: initial === undefined ? null : initial }
    return fiber.hooks[index]
  },
  useMemo(fn) {
    return fn()
  },
}

const requireModule = (id) => {
  if (id === 'react') return fakeReact
  throw new Error(`unexpected require(${id})`)
}

new Function('window', 'require', code)(fakeWindow, requireModule)
check(loaded !== null, 'client.js did not call __ModuleLoader__.load')
if (loaded === null) {
  console.error('FAIL\n - ' + fail.join('\n - '))
  process.exit(1)
}
check(loaded.id === '@local/dsh-shot', `module id is ${loaded.id}`)

const fibers = new Map()
function renderComponent(component, props) {
  if (!fibers.has(component)) fibers.set(component, { hooks: [], index: 0, dirty: false })
  fiber = fibers.get(component)
  let tree = null
  for (let pass = 0; pass < 25; pass += 1) {
    fiber.index = 0
    fiber.dirty = false
    tree = component(props)
    if (fiber.dirty === false) break
  }
  return tree
}

function collectButtons(tree) {
  const found = []
  const walk = (node) => {
    if (node === null || typeof node !== 'object') return
    if (node.type === 'button') found.push(node)
    if (Array.isArray(node.children)) node.children.forEach(walk)
  }
  walk(tree)
  return found
}

function findElement(tree, type) {
  let found = null
  const walk = (node) => {
    if (found !== null || node === null || typeof node !== 'object') return
    if (node.type === type) {
      found = node
      return
    }
    if (Array.isArray(node.children)) node.children.forEach(walk)
  }
  walk(tree)
  return found
}

/* ------------------------------ fake cordis ----------------------------- */
const registered = []
const dictionaries = []
let conversation = null

const fakeCtx = {
  effect(fn) {
    fn()
    return () => {}
  },
  locale: {
    register(namespace, dictionariesArg) {
      dictionaries.push({ namespace, dictionaries: dictionariesArg })
      return () => {}
    },
    bind() {
      return (key, params) => (params === undefined ? key : `${key} ${JSON.stringify(params)}`)
    },
  },
  slots: {
    inject(_slot, register) {
      register()
      return () => {}
    },
    register(entry, component) {
      registered.push({ slot: entry.name, entry, component })
      return () => {}
    },
  },
  get(key) {
    return key === 'conversation' ? conversation : undefined
  },
}

const api = loaded.factory(requireModule)
check(typeof api.apply === 'function', 'module has no apply()')
if (typeof api.apply !== 'function') {
  console.error('FAIL\n - ' + fail.join('\n - '))
  process.exit(1)
}
api.apply(fakeCtx)

check(api.name === 'dsh-shot', `name is ${api.name}`)
check(
  registered.some((item) => item.slot === 'conversation.input.left' && item.entry.id === 'dsh-shot.trigger'),
  'trigger slot not registered',
)
check(
  registered.some((item) => item.slot === 'shell.overlay' && item.entry.id === 'dsh-shot.overlay'),
  'overlay slot not registered',
)
check(dictionaries.length === 1 && dictionaries[0].namespace === 'dsh-shot', 'locale dictionaries not registered')

/* ----------------------------- browser stubs ---------------------------- */
let fetchCalls = 0
globalThis.fetch = async (path, init) => {
  fetchCalls += 1
  if (path !== '/dsh-shot/capture') throw new Error(`unexpected fetch ${path}`)
  if (init === undefined || init.credentials !== 'same-origin') throw new Error('capture fetch lost same-origin credentials')
  return { ok: true, status: 200, blob: async () => new Blob([new Uint8Array(32)], { type: 'image/png' }) }
}
let created = 0
let revoked = 0
globalThis.URL.createObjectURL = () => {
  created += 1
  return `blob:shot-${created}`
}
globalThis.URL.revokeObjectURL = () => {
  revoked += 1
}
globalThis.File = class FakeFile extends Blob {
  constructor(parts, name, options) {
    super(parts, options)
    this.name = name
  }
}
globalThis.Image = class FakeImage {
  set src(value) {
    this.naturalWidth = 2560
    this.naturalHeight = 1600
    Promise.resolve().then(() => this.onload())
  }
}
const canvasCalls = []
globalThis.document = {
  createElement(tag) {
    if (tag !== 'canvas') throw new Error(`unexpected element ${tag}`)
    const canvas = {
      width: 0,
      height: 0,
      getContext: () => ({ drawImage: (...args) => canvasCalls.push(args) }),
      toBlob: (callback, type) => callback(new Blob([new Uint8Array(16)], { type })),
    }
    return canvas
  },
}

/* ------------------------------- the press ------------------------------ */
const createdDrafts = []
const attached = []
const released = []
conversation = {
  createDrafts(sessionId, files) {
    createdDrafts.push({ sessionId, files })
    return files.map((_file, index) => ({ id: `draft-${index}` }))
  },
  releaseDraftAttachments(drafts) {
    released.push(drafts.length)
  },
}

const t = fakeCtx.locale.bind()
const inputActions = {
  addAttachments(ids) {
    attached.push(ids)
    return true
  },
}
const trigger = registered.find((item) => item.slot === 'conversation.input.left').component
const overlay = registered.find((item) => item.slot === 'shell.overlay').component

const triggerTree = renderComponent(trigger, { t, sessionId: 'session-1', inputActions })
check(triggerTree.type === 'button', 'trigger is not a button')
check(triggerTree.props.disabled === false, 'trigger renders disabled while idle')
check(typeof triggerTree.props.onClick === 'function', 'trigger has no click handler')
check(typeof triggerTree.props.onContextMenu === 'function', 'trigger has no context-menu handler')
check(triggerTree.props['aria-label'] === 'button', 'trigger aria-label is not localized')

const fakeEvent = { preventDefault() {}, stopPropagation() {} }

// Idle: the crop surface must render nothing at all.
let overlayTree = renderComponent(overlay, { t })
check(overlayTree === null, 'overlay rendered while idle')

triggerTree.props.onClick(fakeEvent)
await tick()
check(fetchCalls === 1, `expected one capture fetch after click, saw ${fetchCalls}`)
check(created === 1, `expected one object URL, saw ${created}`)

// Right-click = delayed grab: one more fetch, still hidden while capturing.
triggerTree.props.onContextMenu(fakeEvent)
await tick()
check(fetchCalls === 2, `expected a second capture fetch after right-click, saw ${fetchCalls}`)

/* ------------------------- mount and lay out the surface ---------------- */
overlayTree = renderComponent(overlay, { t })
check(overlayTree !== null, 'overlay rendered nothing while picking')
if (overlayTree === null) {
  console.error('FAIL\n - ' + fail.join('\n - '))
  process.exit(1)
}

const containerNode = {
  getBoundingClientRect: () => ({ left: 0, top: 0, width: 1600, height: 1000, right: 1600, bottom: 1000 }),
  setPointerCapture() {},
  releasePointerCapture() {},
  hasPointerCapture: () => false,
}
const imageNode = {
  getBoundingClientRect: () => ({ left: 80, top: 50, width: 1440, height: 900, right: 1520, bottom: 950 }),
  naturalWidth: 2560,
  naturalHeight: 1600,
}

const surface = overlayTree
const imageElement = findElement(surface, 'img')
check(imageElement !== null, 'crop surface has no <img>')
check(imageElement !== null && typeof imageElement.props.onLoad === 'function', '<img> has no load handler')
if (imageElement !== null) {
  imageElement.props.onLoad({ currentTarget: imageNode })
  surface.props.ref.current = containerNode
  imageElement.props.ref.current = imageNode
  overlayTree = renderComponent(overlay, { t })
}

let buttons = collectButtons(overlayTree)
check(buttons.length === 5, `overlay exposes ${buttons.length} buttons (expected 5)`)
const insertButton = buttons[buttons.length - 1]
check(insertButton.props.disabled === true, 'insert is enabled before a region is picked')

// "Whole screen" -> a full-frame selection -> insert becomes enabled.
buttons[0].props.onClick()
overlayTree = renderComponent(overlay, { t })
buttons = collectButtons(overlayTree)
check(buttons.length === 5, `after selecting the whole frame the toolbar has ${buttons.length} buttons`)
const readyButton = buttons[buttons.length - 1]
check(readyButton.props.disabled === false, 'insert stayed disabled after selecting the whole frame')

readyButton.props.onClick()
await tick()

check(canvasCalls.length === 1, `expected one drawImage, saw ${canvasCalls.length}`)
check(createdDrafts.length === 1, `expected one createDrafts call, saw ${createdDrafts.length}`)
if (createdDrafts.length === 1) {
  const draft = createdDrafts[0]
  check(draft.sessionId === 'session-1', `createDrafts session was ${draft.sessionId}`)
  check(draft.files.length === 1 && draft.files[0] instanceof Blob, 'createDrafts did not receive a Blob file')
  check(draft.files[0].type === 'image/png', `file type was ${draft.files[0].type}`)
  check(/^dsh-screenshot-\d{8}-\d{6}\.png$/.test(draft.files[0].name), `file name was ${draft.files[0].name}`)
}
check(attached.length === 1 && attached[0][0] === 'draft-0', `addAttachments saw ${JSON.stringify(attached)}`)
check(released.length === 0, 'insert was rolled back even though addAttachments returned true')
check(revoked > 0, 'object URLs were never revoked')

// After a successful insert the surface closes itself.
overlayTree = renderComponent(overlay, { t })
check(overlayTree === null, 'overlay stayed open after inserting')

if (fail.length > 0) {
  console.error('FAIL\n - ' + fail.join('\n - '))
  process.exit(1)
}
console.log(
  [
    'OK',
    `slots=${registered.map((item) => `${item.slot}/${item.entry.id}`).join(',')}`,
    `fetches=${fetchCalls}`,
    `buttons=${buttons.length}`,
    `drafts=${createdDrafts.length}`,
    `attachments=${JSON.stringify(attached)}`,
    `crop=${JSON.stringify(canvasCalls[0][1] === undefined ? null : canvasCalls[0].slice(1))}`,
    `revoked=${revoked}`,
  ].join(' '),
)
