window.__ModuleLoader__.load({
  id: '@local/dsh-shot',
  factory(require) {
    const React = require('react')
    const h = React.createElement

    const name = 'dsh-shot'
    const inject = ['slots', 'locale']

    const NS = 'dsh-shot'
    /** Same-origin route published by this bundle's Host half. */
    const CAPTURE_PATH = '/dsh-shot/capture'
    /** Longest edge of the attachment: a screenshot is a reference, not an archive. */
    const MAX_EDGE = 2400
    /** Below this the gesture counts as a click, which selects the whole screen. */
    const MIN_DRAG_PX = 4
    /** Grace period that lets the user bring another window to the front. */
    const DELAY_MS = 3000

    const zh = {
      button: '截图',
      tooltip: '截取屏幕区域，加入对话（右键：延时 3 秒截取）',
      delay: '延时 3 秒',
      hint: '拖拽框选区域，单击选择整屏，Esc 取消',
      whole: '整屏',
      retake: '重新截取',
      cancel: '取消',
      insert: '加入对话',
      inserting: '正在加入…',
      failed: '截取失败',
      insertFailed: '无法加入对话',
      noConversation: '对话输入框还没有准备好',
      busy: '正在加入，请稍候',
      selection: '已选 {width} × {height}',
      empty: '拖拽选择区域',
      retry: '重试',
    }

    const en = {
      button: 'Screenshot',
      tooltip: 'Capture a screen region and attach it (right-click: capture in 3 s)',
      delay: 'In 3 s',
      hint: 'Drag to select a region, click for the whole screen, Esc to cancel',
      whole: 'Whole screen',
      retake: 'Recapture',
      cancel: 'Cancel',
      insert: 'Add to chat',
      inserting: 'Adding…',
      failed: 'Capture failed',
      insertFailed: 'Could not add to the chat',
      noConversation: 'The composer is not ready yet',
      busy: 'Adding, please wait',
      selection: '{width} × {height} selected',
      empty: 'Drag to select a region',
      retry: 'Retry',
    }

    /* ------------------------- shared shot state ------------------------ */
    /**
     * `conversation.input.left` is session scoped and `shell.overlay` is root
     * scoped, so the two halves cannot pass props to each other. The button
     * writes the binding and the overlay reads it from this store.
     */
    const state = {
      phase: 'idle', // idle | capturing | picking | error
      imageUrl: null,
      sessionId: null,
      inputActions: null,
      busy: false,
      error: null,
      notice: null,
    }
    const listeners = new Set()
    let inflight = false
    /** Set once in apply: the crop surface is a separate slot entry from the button. */
    let commitShot = null

    function patchState(patch) {
      Object.assign(state, patch)
      listeners.forEach((notify) => notify())
    }

    function resetState() {
      if (state.imageUrl !== null) URL.revokeObjectURL(state.imageUrl)
      patchState({
        phase: 'idle',
        imageUrl: null,
        sessionId: null,
        inputActions: null,
        busy: false,
        error: null,
        notice: null,
      })
    }

    function useSnapshot() {
      const [, bump] = React.useState(0)
      React.useEffect(() => {
        const notify = () => bump((value) => value + 1)
        listeners.add(notify)
        return () => {
          listeners.delete(notify)
        }
      }, [])
      return state
    }

    /* ----------------------------- capture ------------------------------ */

    function messageOf(error) {
      if (error instanceof Error && error.message !== '') return error.message
      const text = String(error)
      return text === '' ? 'unknown error' : text
    }

    async function failureDetail(response) {
      try {
        const body = await response.json()
        if (body !== null && typeof body === 'object' && typeof body.error === 'string') return body.error
      } catch {
        /* not JSON: fall through to the text body */
      }
      const text = await response.text().catch(() => '')
      return text === '' ? `HTTP ${response.status}` : text
    }

    async function runCapture() {
      if (inflight) return
      inflight = true
      try {
        const response = await fetch(CAPTURE_PATH, {
          method: 'GET',
          cache: 'no-store',
          credentials: 'same-origin',
        })
        if (!response.ok) throw new Error(await failureDetail(response))
        const blob = await response.blob()
        if (blob.size === 0) throw new Error('empty screenshot')
        if (state.imageUrl !== null) URL.revokeObjectURL(state.imageUrl)
        patchState({ phase: 'picking', imageUrl: URL.createObjectURL(blob), error: null, notice: null, busy: false })
      } catch (error) {
        patchState({ phase: 'error', error: messageOf(error), imageUrl: null, busy: false })
      } finally {
        inflight = false
      }
    }

    /**
     * Arm a capture. The surface that asked for it is unmounted for the whole
     * `capturing` phase, so it is never part of its own screenshot; `delayMs`
     * gives the user time to bring another window to the front first.
     */
    function armShot(extra, delayMs) {
      if (state.phase === 'capturing') return
      if (state.imageUrl !== null) URL.revokeObjectURL(state.imageUrl)
      patchState({ phase: 'capturing', imageUrl: null, error: null, notice: null, busy: false, ...extra })
      if (delayMs > 0) {
        window.setTimeout(() => {
          void runCapture()
        }, delayMs)
        return
      }
      void runCapture()
    }

    function beginCapture(sessionId, inputActions) {
      if (sessionId === undefined || sessionId === null) return
      if (inputActions === undefined || inputActions === null) return
      armShot({ sessionId, inputActions }, 0)
    }

    function beginDelayedCapture(sessionId, inputActions) {
      if (sessionId === undefined || sessionId === null) return
      if (inputActions === undefined || inputActions === null) return
      armShot({ sessionId, inputActions }, DELAY_MS)
    }

    /** Capture again; `delayMs` lets the user swap the window behind DSH first. */
    function recapture(delayMs = 0) {
      armShot({}, delayMs)
    }

    function closeOverlay() {
      resetState()
    }

    /* ----------------------------- encoding ----------------------------- */

    function loadImage(url) {
      return new Promise((resolve, reject) => {
        const image = new Image()
        image.onload = () => resolve(image)
        image.onerror = () => reject(new Error('the screenshot could not be decoded'))
        image.src = url
      })
    }

    async function cropToBlob(url, rect) {
      const image = await loadImage(url)
      const scale = Math.min(1, MAX_EDGE / Math.max(rect.width, rect.height))
      const width = Math.max(1, Math.round(rect.width * scale))
      const height = Math.max(1, Math.round(rect.height * scale))
      const canvas = document.createElement('canvas')
      canvas.width = width
      canvas.height = height
      const context = canvas.getContext('2d')
      if (context === null) throw new Error('canvas is unavailable')
      context.imageSmoothingQuality = 'high'
      context.drawImage(image, rect.x, rect.y, rect.width, rect.height, 0, 0, width, height)
      const blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/png'))
      if (blob === null) throw new Error('the selection could not be encoded')
      return blob
    }

    function pad(value) {
      return String(value).padStart(2, '0')
    }

    function fileName(now) {
      const stamp =
        `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}` +
        `-${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`
      return `dsh-screenshot-${stamp}.png`
    }

    /* -------------------------- draft insertion ------------------------- */

    /**
     * Hand a PNG File to the composer. The chat UI turns image files into
     * browser-side draft attachments, so `createDrafts` + `addAttachments` is
     * the same path the paperclip button takes.
     */
    function makeInsert(ctx) {
      return function insertShot(sessionId, inputActions, file) {
        const conversation = ctx.get('conversation')
        if (conversation === undefined || conversation === null) {
          throw Object.assign(new Error('no-conversation'), { code: 'noConversation' })
        }
        const drafts = conversation.createDrafts(sessionId, [file])
        const ids = drafts.map((draft) => draft.id)
        let accepted = false
        try {
          accepted = inputActions.addAttachments(ids) === true
        } catch (error) {
          conversation.releaseDraftAttachments(drafts)
          throw error
        }
        if (!accepted) {
          conversation.releaseDraftAttachments(drafts)
          throw Object.assign(new Error('busy'), { code: 'busy' })
        }
      }
    }

    function makeCommit(insertShot, t) {
      function noticeOf(error) {
        const code = error !== null && typeof error === 'object' ? error.code : undefined
        if (code === 'busy' || code === 'noConversation') return t(code)
        return `${t('insertFailed')}: ${messageOf(error)}`
      }

      return async function commitSelection(rect) {
        if (state.phase !== 'picking' || state.imageUrl === null || state.busy) return
        patchState({ busy: true, notice: null })
        try {
          const blob = await cropToBlob(state.imageUrl, rect)
          const file = new File([blob], fileName(new Date()), { type: 'image/png' })
          insertShot(state.sessionId, state.inputActions, file)
          closeOverlay()
        } catch (error) {
          patchState({ busy: false, notice: noticeOf(error) })
        }
      }
    }

    /* ----------------------------- styling ------------------------------ */

    function buttonStyle(hover, busy) {
      return {
        width: 28,
        height: 28,
        display: 'grid',
        placeItems: 'center',
        padding: 0,
        border: 'none',
        borderRadius: 999,
        background: hover && !busy ? 'var(--dsw-alias-bg-layer-2, rgba(255, 255, 255, 0.08))' : 'transparent',
        color: 'var(--dsw-alias-label-secondary, #9aa4b2)',
        opacity: busy ? 0.5 : 1,
        cursor: busy ? 'default' : 'pointer',
        transition: 'background 120ms ease, color 120ms ease',
      }
    }

    function barButtonStyle(kind) {
      const primary = kind === 'primary'
      const quiet = kind === 'quiet'
      return {
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 6,
        height: 30,
        padding: primary ? '0 16px' : '0 12px',
        border: primary ? 'none' : '1px solid var(--dsw-alias-border-l2, rgba(255, 255, 255, 0.16))',
        borderRadius: 999,
        background: primary ? 'var(--dsw-alias-brand-primary, #4b8bf5)' : 'transparent',
        color: primary ? '#ffffff' : 'var(--dsw-alias-label-primary, #e8eefc)',
        font: 'inherit',
        fontSize: 12,
        lineHeight: 1,
        opacity: quiet ? 0.65 : 1,
        cursor: 'pointer',
        whiteSpace: 'nowrap',
      }
    }

    const SURFACE_STYLE = {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 24,
      background: 'rgba(8, 11, 18, 0.62)',
      cursor: 'crosshair',
      userSelect: 'none',
      touchAction: 'none',
      WebkitUserSelect: 'none',
    }

    const IMAGE_STYLE = {
      maxWidth: '100%',
      maxHeight: '100%',
      display: 'block',
      borderRadius: 6,
      boxShadow: '0 24px 70px rgba(0, 0, 0, 0.5)',
      pointerEvents: 'none',
      userSelect: 'none',
      WebkitUserDrag: 'none',
    }

    const SELECTION_STYLE = {
      position: 'absolute',
      border: '1.5px solid var(--dsw-alias-brand-primary, #4b8bf5)',
      borderRadius: 4,
      boxShadow: '0 0 0 9999px rgba(8, 11, 18, 0.55)',
      pointerEvents: 'none',
    }

    const BAR_STYLE = {
      position: 'absolute',
      left: '50%',
      bottom: 22,
      transform: 'translateX(-50%)',
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      maxWidth: 'calc(100% - 48px)',
      padding: '8px 10px',
      borderRadius: 14,
      background: 'var(--dsw-alias-bg-overlay, rgba(22, 26, 36, 0.94))',
      boxShadow: '0 16px 48px rgba(0, 0, 0, 0.45)',
      cursor: 'default',
    }

    const PILL_STYLE = {
      display: 'inline-flex',
      alignItems: 'center',
      height: 30,
      padding: '0 10px',
      borderRadius: 999,
      background: 'var(--dsw-alias-bg-layer-2, rgba(255, 255, 255, 0.08))',
      color: 'var(--dsw-alias-label-secondary, #9aa4b2)',
      fontSize: 12,
      fontVariantNumeric: 'tabular-nums',
      whiteSpace: 'nowrap',
    }

    const HINT_STYLE = {
      position: 'absolute',
      top: 20,
      left: '50%',
      transform: 'translateX(-50%)',
      padding: '7px 14px',
      borderRadius: 999,
      background: 'var(--dsw-alias-bg-overlay, rgba(22, 26, 36, 0.94))',
      color: 'var(--dsw-alias-label-secondary, #9aa4b2)',
      fontSize: 12,
      whiteSpace: 'nowrap',
      cursor: 'default',
    }

    const NOTICE_STYLE = {
      color: 'var(--dsw-alias-state-error-primary, #ef5b5b)',
      fontSize: 12,
      maxWidth: 240,
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
    }

    /* ---------------------------- components ---------------------------- */

    function ViewfinderIcon() {
      return h(
        'svg',
        { width: 16, height: 16, viewBox: '0 0 24 24', fill: 'none', 'aria-hidden': 'true' },
        h('path', { d: 'M4 9V6a2 2 0 0 1 2-2h3', stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round' }),
        h('path', { d: 'M15 4h3a2 2 0 0 1 2 2v3', stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round' }),
        h('path', { d: 'M20 15v3a2 2 0 0 1-2 2h-3', stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round' }),
        h('path', { d: 'M9 20H6a2 2 0 0 1-2-2v-3', stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round' }),
        h('rect', {
          x: 8.5,
          y: 8.5,
          width: 7,
          height: 7,
          rx: 1.6,
          stroke: 'currentColor',
          strokeWidth: 1.6,
          strokeDasharray: '2.2 1.8',
        })
      )
    }

    /** Composer trigger, in the left cluster of the composer tool row. */
    function ShotButton(props) {
      const t = props.t
      const snapshot = useSnapshot()
      const [hover, setHover] = React.useState(false)
      const busy = snapshot.phase === 'capturing'

      return h(
        'button',
        {
          type: 'button',
          title: t('tooltip'),
          'aria-label': t('button'),
          disabled: busy,
          onClick: (event) => {
            event.preventDefault()
            event.stopPropagation()
            beginCapture(props.sessionId, props.inputActions)
          },
          // Right-click waits a few seconds, so another window can come forward first.
          onContextMenu: (event) => {
            event.preventDefault()
            event.stopPropagation()
            beginDelayedCapture(props.sessionId, props.inputActions)
          },
          // Keep the caret and the draft text where they are.
          onMouseDown: (event) => {
            event.preventDefault()
          },
          onMouseEnter: () => setHover(true),
          onMouseLeave: () => setHover(false),
          style: buttonStyle(hover, busy),
        },
        h(ViewfinderIcon, null)
      )
    }

    /** Frame-wide crop surface; only mounted once there is an image to crop. */
    function ShotOverlay(props) {
      const t = props.t
      const snapshot = useSnapshot()
      const containerRef = React.useRef(null)
      const imageRef = React.useRef(null)
      const [drag, setDrag] = React.useState(null)
      const [selection, setSelection] = React.useState(null)
      const [natural, setNatural] = React.useState(null)

      const active = snapshot.phase === 'picking' || snapshot.phase === 'error'

      React.useEffect(() => {
        if (!active) return undefined
        const onKeyDown = (event) => {
          if (event.key !== 'Escape') return
          event.preventDefault()
          event.stopPropagation()
          closeOverlay()
        }
        window.addEventListener('keydown', onKeyDown, true)
        return () => window.removeEventListener('keydown', onKeyDown, true)
      }, [active])

      React.useEffect(() => {
        setSelection(null)
        setDrag(null)
        setNatural(null)
      }, [snapshot.imageUrl])

      if (!active) return null

      if (snapshot.phase === 'error') {
        return h(
          'div',
          { style: { ...SURFACE_STYLE, cursor: 'default' } },
          h(
            'div',
            {
              style: {
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: 14,
                maxWidth: 460,
                padding: '22px 24px',
                borderRadius: 16,
                background: 'var(--dsw-alias-bg-overlay, rgba(22, 26, 36, 0.96))',
                boxShadow: '0 24px 70px rgba(0, 0, 0, 0.5)',
                cursor: 'default',
              },
            },
            h(
              'div',
              { style: { fontSize: 14, fontWeight: 600, color: 'var(--dsw-alias-label-primary, #e8eefc)' } },
              t('failed')
            ),
            h(
              'div',
              {
                style: {
                  fontSize: 12,
                  lineHeight: 1.6,
                  textAlign: 'center',
                  color: 'var(--dsw-alias-label-secondary, #9aa4b2)',
                  wordBreak: 'break-word',
                },
              },
              snapshot.error
            ),
            h(
              'div',
              { style: { display: 'flex', gap: 8, marginTop: 2 } },
              h('button', { type: 'button', style: barButtonStyle('primary'), onClick: () => recapture() }, t('retry')),
              h(
                'button',
                { type: 'button', style: barButtonStyle('quiet'), onClick: () => closeOverlay() },
                t('cancel')
              )
            )
          )
        )
      }

      function measure() {
        const container = containerRef.current
        const image = imageRef.current
        if (container === null || image === null) return null
        const outer = container.getBoundingClientRect()
        const inner = image.getBoundingClientRect()
        if (inner.width <= 0 || inner.height <= 0) return null
        return {
          left: inner.left - outer.left,
          top: inner.top - outer.top,
          width: inner.width,
          height: inner.height,
        }
      }

      function localPoint(event) {
        const container = containerRef.current
        if (container === null) return null
        const outer = container.getBoundingClientRect()
        return { x: event.clientX - outer.left, y: event.clientY - outer.top }
      }

      function clampSelection(from, to) {
        const box = measure()
        if (box === null) return null
        const left = Math.max(box.left, Math.min(from.x, to.x))
        const top = Math.max(box.top, Math.min(from.y, to.y))
        const right = Math.min(box.left + box.width, Math.max(from.x, to.x))
        const bottom = Math.min(box.top + box.height, Math.max(from.y, to.y))
        if (right - left < MIN_DRAG_PX || bottom - top < MIN_DRAG_PX) return null
        return { left, top, width: right - left, height: bottom - top }
      }

      function toNatural(picked) {
        const box = measure()
        if (box === null || natural === null) return null
        const scaleX = natural.width / box.width
        const scaleY = natural.height / box.height
        return {
          x: Math.round((picked.left - box.left) * scaleX),
          y: Math.round((picked.top - box.top) * scaleY),
          width: Math.round(picked.width * scaleX),
          height: Math.round(picked.height * scaleY),
        }
      }

      function selectWholeScreen() {
        const box = measure()
        if (box === null) return
        setSelection({ left: box.left, top: box.top, width: box.width, height: box.height })
      }

      const dragBox = drag === null ? null : clampSelection({ x: drag.x0, y: drag.y0 }, { x: drag.x1, y: drag.y1 })
      const shown = dragBox === null ? selection : dragBox
      const naturalRect = shown === null ? null : toNatural(shown)
      const sizeLabel =
        naturalRect === null
          ? t('empty')
          : t('selection', { width: naturalRect.width, height: naturalRect.height })

      return h(
        'div',
        {
          ref: containerRef,
          style: SURFACE_STYLE,
          onPointerDown: (event) => {
            if (event.button !== 0) return
            const point = localPoint(event)
            if (point === null) return
            event.currentTarget.setPointerCapture(event.pointerId)
            setDrag({ x0: point.x, y0: point.y, x1: point.x, y1: point.y })
          },
          onPointerMove: (event) => {
            if (drag === null) return
            const point = localPoint(event)
            if (point === null) return
            setDrag({ x0: drag.x0, y0: drag.y0, x1: point.x, y1: point.y })
          },
          onPointerUp: (event) => {
            if (drag === null) return
            const target = event.currentTarget
            if (target.hasPointerCapture(event.pointerId)) target.releasePointerCapture(event.pointerId)
            const point = localPoint(event)
            const picked = point === null ? null : clampSelection({ x: drag.x0, y: drag.y0 }, point)
            setDrag(null)
            if (picked === null) {
              selectWholeScreen()
              return
            }
            setSelection(picked)
          },
          onPointerCancel: () => {
            setDrag(null)
          },
        },
        h('div', { style: HINT_STYLE }, t('hint')),
        h('img', {
          ref: imageRef,
          src: snapshot.imageUrl,
          alt: '',
          draggable: false,
          style: IMAGE_STYLE,
          onLoad: (event) => {
            setNatural({ width: event.currentTarget.naturalWidth, height: event.currentTarget.naturalHeight })
          },
        }),
        shown === null
          ? null
          : h('div', {
              style: {
                ...SELECTION_STYLE,
                left: shown.left,
                top: shown.top,
                width: shown.width,
                height: shown.height,
              },
            }),
        h(
          'div',
          { style: BAR_STYLE, onPointerDown: (event) => event.stopPropagation() },
          h('span', { style: { ...PILL_STYLE, minWidth: 96, justifyContent: 'center' } }, sizeLabel),
          snapshot.notice === null ? null : h('span', { style: NOTICE_STYLE, title: snapshot.notice }, snapshot.notice),
          h(
            'button',
            { type: 'button', style: barButtonStyle('quiet'), onClick: () => selectWholeScreen() },
            t('whole')
          ),
          h('button', { type: 'button', style: barButtonStyle('quiet'), onClick: () => recapture() }, t('retake')),
          // Same grab, but with time to bring another window to the front.
          h('button', { type: 'button', style: barButtonStyle('quiet'), onClick: () => recapture(DELAY_MS) }, t('delay')),
          h('button', { type: 'button', style: barButtonStyle('quiet'), onClick: () => closeOverlay() }, t('cancel')),
          h(
            'button',
            {
              type: 'button',
              disabled: naturalRect === null || snapshot.busy,
              style: {
                ...barButtonStyle('primary'),
                opacity: naturalRect === null || snapshot.busy ? 0.55 : 1,
                cursor: naturalRect === null || snapshot.busy ? 'default' : 'pointer',
              },
              onClick: () => {
                if (naturalRect === null) return
                if (commitShot !== null) void commitShot(naturalRect)
              },
            },
            snapshot.busy ? t('inserting') : t('insert')
          )
        )
      )
    }

    /* ------------------------------ wiring ------------------------------ */

    function apply(ctx) {
      ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'dsh-shot: dictionaries')
      const t = ctx.locale.bind(NS)
      commitShot = makeCommit(makeInsert(ctx), t)

      ctx.slots.inject('conversation.input.left', () =>
        ctx.slots.register(
          { name: 'conversation.input.left', id: 'dsh-shot.trigger', order: 20, locale: NS },
          ShotButton
        )
      )

      ctx.slots.inject('shell.overlay', () =>
        ctx.slots.register({ name: 'shell.overlay', id: 'dsh-shot.overlay', order: 40, locale: NS }, ShotOverlay)
      )
    }

    return { name, inject, apply }
  },
})
